 <script type="text/javascript">

function clicked(e){
{
    if(!confirm('your message submitted')){
        else.preventDefault();
    }
}
}</script>